var searchData=
[
  ['temp_0',['temp',['../class_liczydelko__v3_1_1dzialanie.html#a420a2d9e11581e0e3cd357976fd064f8',1,'Liczydelko_v3::dzialanie']]]
];
