var searchData=
[
  ['dzialanie_0',['dzialanie',['../class_liczydelko__v3_1_1dzialanie.html',1,'Liczydelko_v3']]]
];
