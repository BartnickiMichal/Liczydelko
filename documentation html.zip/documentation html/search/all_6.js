var searchData=
[
  ['rozwiaz_0',['rozwiaz',['../class_liczydelko__v3_1_1dzialanie.html#a1eb92ec1bfb7fad2bb612acea969acb5',1,'Liczydelko_v3::dzialanie']]]
];
