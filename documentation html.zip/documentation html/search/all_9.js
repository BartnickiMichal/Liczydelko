var searchData=
[
  ['wynik_0',['wynik',['../class_liczydelko__v3_1_1dzialanie.html#a907e7c60584259afd77efc4375864adb',1,'Liczydelko_v3::dzialanie']]]
];
