var searchData=
[
  ['g1_5fglick_0',['g1_glick',['../class_liczydelko__v3_1_1click.html#adad9b3ae7d4c51b79ea6a61cd9521587',1,'Liczydelko_v3::click']]],
  ['game1_1',['Game1',['../class_liczydelko__v3_1_1_game1.html#aa96f5b421188d36d98627f8a28315050',1,'Liczydelko_v3.Game1.Game1()'],['../class_liczydelko__v3_1_1_game1.html',1,'Liczydelko_v3.Game1']]]
];
