var searchData=
[
  ['game1_0',['Game1',['../class_liczydelko__v3_1_1_game1.html',1,'Liczydelko_v3']]]
];
