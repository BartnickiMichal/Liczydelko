var searchData=
[
  ['liczydelko_5fv3_0',['Liczydelko_v3',['../namespace_liczydelko__v3.html',1,'']]]
];
