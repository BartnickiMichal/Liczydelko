var searchData=
[
  ['x_0',['x',['../class_liczydelko__v3_1_1dzialanie.html#a9bd8190d3c3db5162028b0c9a273171d',1,'Liczydelko_v3::dzialanie']]]
];
