var searchData=
[
  ['initialize_0',['Initialize',['../class_liczydelko__v3_1_1_game1.html#aa82d4f6f5b842a069deb5a941b4a27e9',1,'Liczydelko_v3::Game1']]]
];
