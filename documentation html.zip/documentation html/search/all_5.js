var searchData=
[
  ['poprawnaodp_0',['poprawnaodp',['../class_liczydelko__v3_1_1dzialanie.html#ac4570136d5c046ca1839c4c6a6f88618',1,'Liczydelko_v3::dzialanie']]]
];
